package com.srini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ViewController {

	@RequestMapping("/register")
	public String getRegi()
	{
		
		return "Register";
	}
	@RequestMapping("/login")
	public String getLog()
	{
		System.out.println("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
		return "Login";
	}
}
