package com.srini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ViewController {

	@RequestMapping("/register")
	public String getRegi()
	{
		
		return "Register";
	}
	@RequestMapping("/login")
	public String getLog()
	{
		return "Login";
	}
	@RequestMapping("/imgA")
	public String getImageData()
	{
		return "ProData";
	}
	@RequestMapping("/product")
	public ModelAndView Products(@RequestParam(value="name", required=false,defaultValue="") String name)
	{
		ModelAndView prod=null;
		
		if("img1".equals(name))
		{
			prod = new ModelAndView("ProData");
			prod.addObject("pid","mi01");
			prod.addObject("pnm","Guitar");
			prod.addObject("pdis","Xyz Company");
			prod.addObject("pprc","5000");
		}
		if("img2".equals(name))
		{
			prod = new ModelAndView("ProData");
			prod.addObject("pod","mi02");
			prod.addObject("pnm","Piyano");
			prod.addObject("pdis","Abc Company");
			prod.addObject("pprc","8000");
		}
		if("img3".equals(name))
		{
			prod = new ModelAndView("ProData");
			prod.addObject("pid","mi03");
			prod.addObject("pnm","Violin");
			prod.addObject("pdis","PQr Company");
			prod.addObject("pprc","3450");
		}
		
		return prod;
	}

	@RequestMapping("/allprod")
	public ModelAndView getAllpro()
	{
		ModelAndView pro=null;
		pro=new ModelAndView("AllProducts");
		return pro;
	}
}
