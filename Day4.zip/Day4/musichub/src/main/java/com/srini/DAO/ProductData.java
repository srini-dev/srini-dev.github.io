package com.srini.DAO;

import java.util.ArrayList;
import java.util.List;

import com.srini.model.Product;

public class ProductData implements ProductList{

	List <Product>lst=new ArrayList<Product>();
	public List<Product> proList() {
		
		Product p1=new Product("mi221", "Guitar", "Company", 5938);
		Product p2=new Product("mi222", "Violin", "Company", 5938);
		Product p3=new Product("mi223", "Piyano", "Company", 5938);
		Product p4=new Product("mi224", "Mridangam", "Company", 5938);
		lst.add(p1);
		lst.add(p2);
		lst.add(p3);
		lst.add(p4);
		return lst;
	} 
	 
	

}
