package com.srini.model;

public class Product {

	public String pid;
	public String pnm;
	public String pdis;
	public double pprc;
	
	public Product(String pid, String pnm, String pdis, double pprc) {
		super();
		this.pid = pid;
		this.pnm = pnm;
		this.pdis = pdis;
		this.pprc = pprc;
	}
	
	public String getPid() {
		return pid;
	}
	public String getPnm() {
		return pnm;
	}
	public String getPdis() {
		return pdis;
	}
	public double getPprc() {
		return pprc;
	}
	
}
