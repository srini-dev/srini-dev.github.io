package com.srini.DAO;
import java.util.*;

import com.srini.model.Product;
public interface ProductList {

	public List<Product> proList();
}
