package com.srini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.srini.DAO.*;
import com.srini.model.*;

import java.util.*;

@Controller
public class ViewController {

	String nam;
	ProductData lst=null;
	@RequestMapping("/register")
	public String getRegi()
	{
		
		return "Register";
	}
	@RequestMapping("/login")
	public String getLog()
	{
		return "Login";
	}
	@RequestMapping("/imgA")
	public String getImageData()
	{
		return "ProData";
	}
	@RequestMapping("/product")
	public ModelAndView Products(@RequestParam(value="name", required=false,defaultValue="") String name)
	{
		ModelAndView prod=null;
		nam=name;
		System.out.println("1VVVVVVVVVVVVVVV "+nam);
		prod=new ModelAndView("AllProducts");
		
		return prod;
	}

	@RequestMapping("/GsonCon")
	public @ResponseBody String listUsers() {
	 
		System.out.println("0VVVVVVVVVVVVVVV "+nam);
		lst=new ProductData();
		String Prods="";
		List <Product> one_pro=new ArrayList<Product>();
		Product pro=null;
		System.out.println("hhhh");
		if("allpro".equals(nam))
	    {
			Gson gson=null;
			System.out.println("2VVVVVVVVVVVVVVV "+nam);
			List<Product> listPro = lst.proList();
			
			gson=new Gson();
			Prods=gson.toJson(listPro);
	    }
		else 
	    {
			Gson gson=null;
			System.out.println("3VVVVVVVVVVVVVVV "+nam);
			List<Product> listPro = lst.proList();
			Iterator itm=listPro.iterator();
			while(itm.hasNext())
			{
				pro=(Product)itm.next();
				if(pro.getPid().equals(nam))
				{one_pro.add(pro);}
			}
			
			gson=new Gson();
			Prods=gson.toJson(one_pro);
	    }
	 
	    return Prods;
	}
}
