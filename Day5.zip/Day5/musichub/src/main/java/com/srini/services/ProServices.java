package com.srini.services;

import java.util.List;


import com.srini.model.Products;



public interface ProServices {

	public void addPro(Products pd);
	public List getAllPro();
}
