package com.srini.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.srini.DAO.ProductData;
import com.srini.model.Products;



public class ProServiceImpl implements ProServices{

	
	private ProductData pd;
	public void addPro(Products pd) {
		// TODO Auto-generated method stub
		
	}

	public List getAllPro() {
		
		return pd.proList();
	}

	
}
