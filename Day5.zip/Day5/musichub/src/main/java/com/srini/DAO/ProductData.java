package com.srini.DAO;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.srini.model.Products;



public class ProductData implements ProductList{

	List <Products>lst=new ArrayList<Products>();
	@Autowired
	private SessionFactory sessionFactory;
	
	public ProductData() 
	{	System.out.println("In ProdData constructor");}
	
	
	
	public void setsessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
		System.out.println("In sett Session Factory");
	}

//	private Session getCurrentSession() {
//		System.out.println("In getSessionFactory");
//		return sessionFactory.getCurrentSession();
//	}

//	public void addProduct(Products pm) {
//		System.out.println("Tab created");
//		getCurrentSession().save(pm);
//	}

	
	public List<Products> proList() {
		
//		Products p1=new Products("mi221", "Guitar", "Company", 5938);
//		Products p2=new Products("mi222", "Violin", "Company", 5938);
//		Products p3=new Products("mi223", "Piyano", "Company", 5938);
//		Products p4=new Products("mi224", "Mridangam", "Company", 5938);
//		lst.add(p1);
//		lst.add(p2);
//		lst.add(p3);
//		lst.add(p4);
//		return lst;
		List<Products> lst;
		System.out.println("KKKKKKKKKKKKKKKKKKKKKKKK Begin");
		//return getCurrentSession().createQuery("from Products").list();
		Session ses=sessionFactory.openSession();
		System.out.println("KKKKKKKKKKKKKKKKKKKKKKKK"+ses.isOpen());
		Query q=ses.createQuery("from Products");
		lst=q.list();
		return lst;
		
	} 
	 
	

}
