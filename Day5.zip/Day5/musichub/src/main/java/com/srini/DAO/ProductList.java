package com.srini.DAO;
import java.util.*;

import com.srini.model.Products;
public interface ProductList {

	public List<Products> proList();
}
